<?php
include "../../conf/conn.php";
if($_POST)
{
$nmas = $_POST['nama_masakan'];
$harga = $_POST['harga'];
$sm = $_POST['status_masakan'];
$query = ("UPDATE masakan SET nama_masakan='$nmas',harga='$harga',status_masakan='$sm'WHERE nama_masakan ='$nmas'");
if(!mysqli_query($koneksi,"$query")){
die(mysqli_error);
}else{
echo '<script>alert("Data Berhasil Diubah !!!");
window.location.href="../../index.php?page=data_menu"</script>';
}
}
?>