<?php
include "../../conf/conn.php";
if($_POST){
$nmas = $_POST['nama_masakan'];
$harga = $_POST['harga'];
$sm = $_POST['status_masakan'];
$query = "INSERT INTO masakan (nama_masakan, harga, status_masakan) VALUES ('$nmas','$harga','$sm')";
// Execute the query
if (!mysqli_query($koneksi, $query)) {
    die("Error: " . mysqli_error($koneksi)); // Print the error message
} else {
    echo '<script>alert("Data Berhasil Ditambahkan !!!");
    window.location.href="../../index.php?page=data_menu"</script>';
}
}
?>
