<?php
include "../../conf/conn.php";

if ($_POST) {
    $lvl = $_POST['nama_level'];

    // Construct the INSERT query
    $query = "INSERT INTO level (nama_level) VALUES ('$lvl')";

    // Execute the query
    if (!mysqli_query($koneksi, $query)) {
        die("Error: " . mysqli_error($koneksi)); // Print the error message
    } else {
        echo '<script>alert("Data Berhasil Ditambahkan !!!");
        window.location.href="../../index.php?page=data_level"</script>';
    }
}
?>
